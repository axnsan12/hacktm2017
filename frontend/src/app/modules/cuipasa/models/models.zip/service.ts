export interface Service {
  id: number;
  name: string;
  alias: string;
}
