import {Filter} from './filter';
import {Service} from './service';
export interface MagicModel {
  filters: Filter[];
  service: Service;
}
