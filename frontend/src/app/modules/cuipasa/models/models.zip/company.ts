export interface Company {
  name: string;
}
