import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';
import {Package} from '../../../../models/package';

@Component({
  selector: 'app-result',
  templateUrl: './result.component.html',
  styleUrls: ['./result.component.scss']
})
export class ResultComponent implements OnInit, OnChanges {

  @Input()
  public pack: Package;

  constructor() {

  }


  ngOnChanges(changes: SimpleChanges): void {

    // console.log(this.pack);
  }

  ngOnInit() {
  }

}
